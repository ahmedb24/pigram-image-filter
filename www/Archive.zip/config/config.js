"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.config = {
    "jwt": {
        "secret": process.env.JWT_SECRET
    },
    "keys": process.env.KEYS
};
//# sourceMappingURL=config.js.map